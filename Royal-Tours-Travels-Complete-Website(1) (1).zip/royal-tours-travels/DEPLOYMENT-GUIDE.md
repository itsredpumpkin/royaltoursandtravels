# Royal Tours & Travels — Deployment Guide

This package contains the complete website source code and all website assets, including the logo, founder photograph, hero image and destination gallery images.

## Requirements

- Node.js 22.13 or newer
- npm

No database or private environment variables are required for this website.

## Run locally

```bash
npm ci
npm run dev
```

Open the local address shown in the terminal.

## Production build

```bash
npm ci
npm run build
npm run start
```

## Upload to GitHub

1. Extract this ZIP.
2. Create an empty GitHub repository.
3. Open a terminal inside the extracted `royal-tours-travels` folder.
4. Run:

```bash
git init
git add .
git commit -m "Initial Royal Tours & Travels website"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## Deploy on Hostinger

Use a Hostinger plan that supports Node.js applications or a Hostinger VPS.

1. Upload and extract the project in the application's root directory.
2. Select Node.js 22 or a newer supported version.
3. Install dependencies with `npm ci`.
4. Set the build command to `npm run build`.
5. Set the start command to `npm run start`.
6. Connect the domain and enable SSL from the Hostinger control panel.

Traditional shared hosting that only provides a `public_html` folder cannot run this source project by itself because the website uses React and Vinext. It requires Hostinger's Node.js application hosting or a VPS.

## Important folders

- `app/` — website pages, content and styling
- `components/` — reusable interface components
- `public/` — logo, founder image, hero image and all gallery images
- `scripts/` — installation and production build helpers

## Contact details used on the website

- Phone and WhatsApp: +91 97492 30783
- Developer credit: https://redpumpkin.in/
