import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Travel Agency & Cab Service in Siliguri | Royal Tours",
  description: "Royal Tours & Travels is a trusted travel agency and booking service centre in Siliguri offering cabs, sightseeing, bus tickets and air ticket booking.",
  keywords: ["Travel Agency in Siliguri", "Cab Service Siliguri", "Booking Service Centre Siliguri", "Siliguri to Darjeeling Cab", "Siliguri to Gangtok Cab", "NJP to Darjeeling Cab", "Bagdogra to Gangtok Cab", "Darjeeling Sightseeing", "Sikkim Tour Booking"],
  robots: { index: true, follow: true },
  icons: { icon: "/royal-logo.png", shortcut: "/royal-logo.png" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en-IN"><body>{children}</body></html>;
}
