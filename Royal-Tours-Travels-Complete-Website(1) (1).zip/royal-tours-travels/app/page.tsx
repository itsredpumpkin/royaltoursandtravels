"use client";

import { useEffect, useRef, useState } from "react";
import {
  ArrowRight, AtSign, CarFront, Clock3, Globe2, Headphones, Map,
  MapPin, MessageCircle, Plane, Route, ShieldCheck, Sparkles, Ticket,
  TrainFront, UsersRound, Camera, ChevronLeft, ChevronRight,
} from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { destinations } from "./destinations";

const whatsapp = "https://wa.me/919749230783?text=Hello%20Royal%20Tours%20%26%20Travels%2C%20I%20would%20like%20to%20know%20more%20about%20your%20cab%2C%20tour%20and%20ticket%20booking%20services.";

const legacyDestinations = [
  { name: "Darjeeling", eyebrow: "Queen of the Hills", description: "Toy-train heritage, rolling tea gardens, Tiger Hill sunrises and timeless Himalayan charm.", sights: "Tiger Hill · Batasia Loop · Ghoom · Mall Road", images: [
    { src: "https://www.hillzonetourism.com/ServerImage/3986904c-cdf8-4204-b709-f6e1cad9bbdf.jpg", label: "Darjeeling Himalayan Railway" },
    { src: "https://i.pinimg.com/736x/9e/b0/ba/9eb0bab9d66f41a0d066c34c48898c84.jpg", label: "Tiger Hill sunrise" },
    { src: "https://oddessemania.in/wp-content/uploads/2025/05/Happy-Valley-Tea-estate-Oddessemania.jpg", label: "Happy Valley tea estate" },
    { src: "https://reveriechaser.com/wp-content/uploads/2015/10/darjeeling-india-tea-plantations-jekabs-andrushaitis-photography-riga-photo-show-travel-himalaya-mountains.jpg", label: "Darjeeling tea country" },
    { src: "https://content.r9cdn.net/rimg/dimg/92/8e/187c4ae9-city-42727-16799670a4c.jpg?crop=true&height=630&width=1200&xhint=1842&yhint=1150", label: "Darjeeling hillside town" },
  ]},
  { name: "Gangtok", eyebrow: "The Sikkim Capital", description: "A lively mountain city where peaceful monasteries, viewpoints and MG Marg come together.", sights: "MG Marg · Rumtek · Tashi View Point · Ganesh Tok", images: [
    { src: "https://cf-img-a-in.tosshub.com/sites/visualstory/wp/2024/06/cropped-MG-marg-thumnail.jpg?size=900%3A1200", label: "MG Marg" },
    { src: "https://media.assettype.com/outlooktraveller/2024-09-03/u7mnflzi/shutterstock_2451863927.jpg?auto=format%2Ccompress&enlarge=true&fit=max&h=675&w=1200", label: "Tsomgo Lake excursion" },
    { src: "https://media1.thrillophilia.com/filestore/pu4uxdz9mu0grvt6r7p9eo17cq2s_shutterstock_415638529.jpg", label: "Sikkim mountain road" },
    { src: "https://mindtrip.ai/attractions/0eff/62d9/cedd/7749/d985/13c4/4bd4/9647", label: "Waterfalls and prayer flags" },
    { src: "https://upload.wikimedia.org/wikipedia/commons/9/91/Ravangla_Buddha_Park%2C_Sikkim.jpg", label: "Sikkim Buddhist heritage" },
  ]},
  { name: "North Sikkim", eyebrow: "High Himalayan Wonder", description: "Dramatic valleys, glacial lakes and unforgettable roads through the wild Himalayas.", sights: "Lachung · Lachen · Yumthang · Gurudongmar", images: [
    { src: "https://storage.googleapis.com/stateless-www-justwravel-com/2025/10/e6edeba3-untitled-design-36.jpg", label: "Gurudongmar Lake" },
    { src: "https://pixahive.com/wp-content/uploads/2020/09/Gurudongmar-Lake-North-Sikkim-66457-pixahive.jpg", label: "Gurudongmar’s turquoise water" },
    { src: "https://peakvisor.com/photo/India-Gurudongmar-Lake-in-North-Sikkim.jpg", label: "High-altitude Himalayan landscape" },
    { src: "https://s2.dmcdn.net/v/UAjKB1Z3H0G5mdMS_/x1080", label: "Yumthang Valley and Zero Point" },
    { src: "https://mindtrip.ai/attractions/0eff/62d9/cedd/7749/d985/13c4/4bd4/9647", label: "Upper Dzongu waterfall" },
  ]},
  { name: "East Sikkim", eyebrow: "Lakes & Silk Route", description: "Alpine lakes, mountain passes and spectacular routes shaped by history and nature.", sights: "Tsomgo Lake · Baba Mandir · Nathula · Silk Route", images: [
    { src: "https://media.assettype.com/outlooktraveller/2024-09-03/u7mnflzi/shutterstock_2451863927.jpg?auto=format%2Ccompress&enlarge=true&fit=max&h=675&w=1200", label: "Tsomgo Lake" },
    { src: "https://media1.thrillophilia.com/filestore/pu4uxdz9mu0grvt6r7p9eo17cq2s_shutterstock_415638529.jpg", label: "Tsomgo lakeside road" },
    { src: "https://holidays.tripfactory.com/sikkim/wp-content/uploads/sites/18/2024/05/Tsomgo-Lake-East-Sikkim-India.webp", label: "Snowy East Sikkim" },
    { src: "https://static2.tripoto.com/media/filter/nl/img/107618/TripDocument/1558846130_zigzag.jpg", label: "Zuluk zigzag Silk Route" },
    { src: "https://cf-img-a-in.tosshub.com/sites/visualstory/wp/2024/06/cropped-MG-marg-thumnail.jpg?size=900%3A1200", label: "Gangtok gateway" },
  ]},
  { name: "South Sikkim", eyebrow: "Spiritual & Scenic", description: "Peaceful monasteries, gardens, tea estates and grand Himalayan viewpoints around Namchi and Ravangla.", sights: "Namchi · Ravangla · Buddha Park · Temi Tea Garden", images: [
    { src: "https://upload.wikimedia.org/wikipedia/commons/9/91/Ravangla_Buddha_Park%2C_Sikkim.jpg", label: "Ravangla Buddha Park" },
    { src: "https://resize.indiatvnews.com/en/centered/newbucket/1200_675/2024/02/sikkim-1709014795.jpg", label: "Buddha Park gardens" },
    { src: "https://sikkimtourism.org/wp-content/uploads/2023/06/Temi-Tea-Garden-in-Ravangla.jpg", label: "Temi Tea Garden" },
    { src: "https://resize.indiatvnews.com/en/resize/newbucket/1200_-/2024/02/sikkim-1709014795.jpg", label: "Namchi mountain park" },
    { src: "https://images.prabhasakshi.com/2022/11/darjeeling_large_1739_23.jpeg", label: "Green Himalayan slopes" },
  ]},
  { name: "West Sikkim", eyebrow: "Sacred Lakes & Peaks", description: "Ancient monasteries, sacred lakes, waterfalls and magnificent Kanchenjunga views around Pelling.", sights: "Pelling · Yuksom · Khecheopalri · Pemayangtse", images: [
    { src: "https://images.beyondyatra.com/dest/west-sikkim/places/pelling-skywalk-sikkim-india_img_8.jpg", label: "Pelling Skywalk" },
    { src: "https://www.lifeberrys.com/img/article/sikkim--khecheopalri-lake-1506167797-lb.jpg", label: "Khecheopalri Lake" },
    { src: "https://peakvisor.com/photo/India-Gurudongmar-Lake-in-North-Sikkim.jpg", label: "Sikkim Himalayan peaks" },
    { src: "https://cdn.guidetour.in/wp-content/uploads/2018/01/Durpin-Dara.jpg.webp", label: "Himalayan monastery gardens" },
    { src: "https://d34vm3j4h7f97z.cloudfront.net/optimized/4X/4/7/2/472250f0eb1e22f1ec9a16ec04a6570da1df9f28_2_690x460.jpeg", label: "Misty mountain forest" },
  ]},
  { name: "Kalimpong", eyebrow: "Quiet Hill Escape", description: "Flower nurseries, monasteries and wide-open views over the Teesta and distant peaks.", sights: "Deolo Hill · Durpin Dara · Monasteries · Nurseries", images: [
    { src: "https://media.assettype.com/outlooktraveller/2024-01/13844b47-3fde-42ba-bb00-b7d79ac23757/Kalimpong_Deolo_Hill.jpg?auto=format%2Ccompress&dpr=1.0&fit=max&format=webp&w=1200", label: "Deolo Hill" },
    { src: "https://cdn.guidetour.in/wp-content/uploads/2018/01/Durpin-Dara.jpg.webp", label: "Durpin Dara" },
    { src: "https://assets.simplotel.com/simplotel/image/upload/x_0%2Cy_205%2Cw_1024%2Ch_577%2Cr_0%2Cc_crop/q_60%2Cw_1400%2Cdpr_1%2Cf_auto%2Cfl_progressive%2Cc_limit/summit-hotels-resorts/cactus-nursery", label: "Cactus nursery" },
    { src: "https://nbstc.in/tourism/file_store/products/big/1270851341686227616s6.jpg", label: "Hillside gardens" },
    { src: "https://images.fusionstays.com/files/?url=https%3A%2F%2Fres.cloudinary.com%2Ffusionstays%2Fimage%2Fupload%2Fc_fill%2Ce_sharpen%3A100%2Cq_auto%2Cf_auto%2Cfl_progressive%2Cw_750%2Ch_500%2Fv1739281035%2Fproperty%2F1350%2Ftvlej9gy5hkgyk4fnk7d.jpg", label: "Kalimpong countryside" },
  ]},
  { name: "Mirik", eyebrow: "Lakeside Serenity", description: "A calm lake, pine forests and tea gardens create an easy, refreshing day in the hills.", sights: "Sumendu Lake · Pine Forest · Tea Gardens · Viewpoints", images: [
    { src: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Mirik_Lake_a.k.a_Sumendu_Lake.jpg/1280px-Mirik_Lake_a.k.a_Sumendu_Lake.jpg", label: "Sumendu Lake" },
    { src: "https://www.beyondyatra.com/assets/images/imgtg/bagdogra/nr/mirik_bagdogra_west_bengal_india.jpg", label: "Mirik lake and bridge" },
    { src: "https://www.sociogenie.com/wp-content/uploads/2016/12/Mirik-west-bengal.jpg", label: "Mirik lakeside" },
    { src: "https://oddessemania.in/wp-content/uploads/2025/05/Happy-Valley-Tea-estate-Oddessemania.jpg", label: "Nearby tea gardens" },
    { src: "https://d34vm3j4h7f97z.cloudfront.net/optimized/4X/4/7/2/472250f0eb1e22f1ec9a16ec04a6570da1df9f28_2_690x460.jpeg", label: "Misty pine forest" },
  ]},
  { name: "Kurseong", eyebrow: "Land of White Orchids", description: "Misty tea estates, colonial echoes and peaceful viewpoints just beyond Siliguri.", sights: "Tea Estates · Eagle’s Crag · Churches · Heritage Railway", images: [
    { src: "https://images.ixigo.com/node_image/f_auto%2Cw_1200/imageURL?url=https%3A%2F%2Fta.ixigo.es%2Fv3%2Fimages-itinerary%2Fkurseong-tea-garden-trails%402x.jpg", label: "Kurseong tea garden trail" },
    { src: "https://media.indulgexpress.com/indulgexpress%2F2025-05-21%2F5j2epc9x%2FDarjeeling-West-Bengal.jpg", label: "Toy train through tea country" },
    { src: "https://reveriechaser.com/wp-content/uploads/2015/10/darjeeling-india-tea-plantations-jekabs-andrushaitis-photography-riga-photo-show-travel-himalaya-mountains.jpg", label: "Misty tea estates" },
    { src: "https://content.r9cdn.net/rimg/dimg/92/8e/187c4ae9-city-42727-16799670a4c.jpg?crop=true&height=630&width=1200&xhint=1842&yhint=1150", label: "Hill town views" },
    { src: "https://images.fusionstays.com/files/?url=https%3A%2F%2Fres.cloudinary.com%2Ffusionstays%2Fimage%2Fupload%2Fc_fill%2Ce_sharpen%3A100%2Cq_auto%2Cf_auto%2Cfl_progressive%2Cw_750%2Ch_500%2Fv1739281035%2Fproperty%2F1350%2Ftvlej9gy5hkgyk4fnk7d.jpg", label: "Quiet Himalayan roads" },
  ]},
  { name: "Offbeat North Bengal", eyebrow: "Beyond the Usual", description: "Slow village stays, hidden viewpoints and peaceful nature for travellers seeking something different.", sights: "Sittong · Tinchuley · Lepchajagat · Village Stays", images: [
    { src: "https://nbstc.in/tourism/file_store/products/big/1270851341686227616s6.jpg", label: "Sittong and Tinchuley" },
    { src: "https://images.fusionstays.com/files/?url=https%3A%2F%2Fres.cloudinary.com%2Ffusionstays%2Fimage%2Fupload%2Fc_fill%2Ce_sharpen%3A100%2Cq_auto%2Cf_auto%2Cfl_progressive%2Cw_750%2Ch_500%2Fv1739281035%2Fproperty%2F1350%2Ftvlej9gy5hkgyk4fnk7d.jpg", label: "Tinchuley valley view" },
    { src: "https://d34vm3j4h7f97z.cloudfront.net/optimized/4X/4/7/2/472250f0eb1e22f1ec9a16ec04a6570da1df9f28_2_690x460.jpeg", label: "Lepchajagat forest" },
    { src: "https://images.prabhasakshi.com/2022/11/darjeeling_large_1739_23.jpeg", label: "Sittong’s misty green hills" },
    { src: "https://reveriechaser.com/wp-content/uploads/2015/10/darjeeling-india-tea-plantations-jekabs-andrushaitis-photography-riga-photo-show-travel-himalaya-mountains.jpg", label: "Tea village landscape" },
  ]},
];

const services = [
  { icon: CarFront, title: "Private Cab Booking", text: "A comfortable, personal journey for families, couples, friends and business travellers." },
  { icon: UsersRound, title: "Sumo & Traveller", text: "Practical vehicle options for group tours, family holidays and larger travel parties." },
  { icon: Map, title: "Local Sightseeing", text: "Thoughtfully planned routes covering popular attractions and beautiful offbeat places." },
  { icon: Plane, title: "Airport Transfers", text: "Pickup and drop assistance from Bagdogra Airport to the hills and surrounding regions." },
  { icon: TrainFront, title: "NJP Transfers", text: "Convenient pickup and drop from New Jalpaiguri Railway Station, subject to availability." },
  { icon: Ticket, title: "Bus & Air Tickets", text: "Friendly assistance with available bus routes and domestic or international air tickets." },
];

const faqs = [
  { q: "Which is a reliable travel agency in Siliguri?", a: "Royal Tours & Travels is a Siliguri-based travel agency with approximately 10 years of experience. We arrange cabs, Sumos, Travellers, sightseeing, bus tickets and air tickets." },
  { q: "Can I book a cab from Siliguri to Darjeeling or Gangtok?", a: "Yes. Cab services can be arranged from Siliguri, NJP Railway Station and Bagdogra Airport to Darjeeling, Gangtok and other destinations, depending on vehicle availability." },
  { q: "Do you provide Bagdogra Airport and NJP pickup?", a: "Yes. Pickup and drop services can be arranged from Bagdogra Airport and NJP Railway Station for Darjeeling, Gangtok, Kalimpong and nearby destinations." },
  { q: "Can you arrange Darjeeling and Sikkim sightseeing?", a: "Yes. We arrange sightseeing across Darjeeling, Gangtok, North, South, East and West Sikkim, Kalimpong, Mirik, Kurseong and nearby offbeat destinations." },
  { q: "Are permits required for Sikkim tours?", a: "Certain Sikkim destinations require government permits. Entry depends on permit approval, identification documents, weather, road conditions and local regulations." },
  { q: "How can I book my journey?", a: "Call or WhatsApp +91 97492 30783 with your dates, pickup point, destination and number of travellers. We will suggest suitable available options." },
];

function Reveal({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(([entry]) => entry.isIntersecting && setShown(true), { threshold: 0.12 });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  return <div ref={ref} className={`reveal ${shown ? "is-visible" : ""} ${className}`}>{children}</div>;
}

function PhoneLinkedText({ text }: { text: string }) {
  const phone = "+91 97492 30783";
  const parts = text.split(phone);
  if (parts.length === 1) return <>{text}</>;
  return <>{parts.map((part, index) => <span key={`${part}-${index}`}>{part}{index < parts.length - 1 && <a className="inline-phone" href="tel:+919749230783">{phone}</a>}</span>)}</>;
}

export default function Home() {
  const [selected, setSelected] = useState<(typeof destinations)[number] | null>(null);
  const [activeImage, setActiveImage] = useState(0);
  const travelAgencySchema = {
    "@context": "https://schema.org", "@type": "TravelAgency", name: "Royal Tours & Travels",
    description: "Travel agency, cab service and ticket booking centre in Siliguri for Darjeeling, Sikkim and North Bengal.",
    telephone: "+91-9749230783", founder: { "@type": "Person", name: "Mr. Ranjan Sahani" },
    address: { "@type": "PostalAddress", streetAddress: "In front of Hotel Tower Bangla, Darjeeling More, Mallaguri", addressLocality: "Siliguri", postalCode: "734003", addressRegion: "West Bengal", addressCountry: "IN" },
    areaServed: ["Siliguri", "Darjeeling", "Gangtok", "Sikkim", "Kalimpong", "Mirik", "Kurseong"],
  };

  return (
    <main>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(travelAgencySchema) }} />
      <header className="site-header">
        <a className="brand" href="#home" aria-label="Royal Tours and Travels home"><img src="/royal-logo.png" alt="Royal Tours & Travels" /></a>
        <nav aria-label="Main navigation"><a href="#about">About</a><a href="#services">Services</a><a href="#destinations">Destinations</a><a href="#contact">Contact</a></nav>
        <a className="header-call" href="tel:+919749230783"><span>Call now</span> +91 97492 30783</a>
      </header>

      <section id="home" className="hero">
        <div className="hero-media" aria-hidden="true" /><div className="hero-scrim" aria-hidden="true" />
        <div className="hero-content">
          <p className="eyebrow"><Sparkles size={14} /> Your gateway to the Eastern Himalayas</p>
          <h1>Travel with comfort.<br /><em>Discover with confidence.</em></h1>
          <p className="hero-copy">A trusted travel agency, cab service and booking centre in Siliguri for Darjeeling, Gangtok, Sikkim and North Bengal.</p>
          <div className="hero-actions">
            <a className="button button-gold" href={whatsapp} target="_blank" rel="noreferrer">Plan your trip <ArrowRight size={17} /></a>
            <a className="button button-ghost" href="tel:+919749230783">Call +91 97492 30783</a>
          </div>
          <div className="hero-trust"><span><Clock3 size={17} /> Approx. 10 years of experience</span><span><MapPin size={17} /> Based in Siliguri</span><span><Route size={17} /> Hills & offbeat routes</span></div>
        </div>
        <a href="#destinations" className="scroll-cue" aria-label="Explore destinations"><span>Explore</span><i /></a>
      </section>

      <section id="about" className="section about-section">
        <Reveal className="about-grid"><div><p className="kicker">Welcome to Royal</p><h2>Your friendly travel partner in <em>Siliguri.</em></h2></div><div className="about-copy"><p>Royal Tours & Travels helps families, couples, friends, groups and business travellers explore the hills without the stress of complicated planning.</p><p>From choosing the right vehicle to arranging sightseeing routes, airport transfers and tickets, we keep every step clear, personal and convenient.</p><a href={whatsapp} target="_blank" rel="noreferrer" className="text-link">Talk to our travel expert <ArrowRight size={16} /></a></div></Reveal>
        <Reveal className="trust-strip"><div><strong>10</strong><span>Years of local experience</span></div><div><strong>10+</strong><span>Core travel regions</span></div><div><strong>6</strong><span>Booking services</span></div><div><strong>1</strong><span>Trusted travel partner</span></div></Reveal>
      </section>

      <section id="services" className="section services-section">
        <Reveal className="section-heading"><div><p className="kicker">Travel, taken care of</p><h2>Everything you need for a <em>comfortable journey.</em></h2></div><p>From your first pickup to the final sightseeing stop, we help keep the journey simple.</p></Reveal>
        <div className="service-grid">{services.map((service, index) => { const Icon = service.icon; return <Reveal key={service.title} className="service-card"><span className="service-number">0{index + 1}</span><Icon className="service-icon" size={28} strokeWidth={1.5} /><h3>{service.title}</h3><p>{service.text}</p><a href={whatsapp} target="_blank" rel="noreferrer" aria-label={`Enquire about ${service.title}`}>Enquire <ArrowRight size={15} /></a></Reveal>; })}</div>
      </section>

      <section id="destinations" className="section destinations-section">
        <Reveal className="section-heading destination-heading"><div><p className="kicker">Popular destinations</p><h2>Every place opens into a <em>beautiful story.</em></h2></div><p>Open a region to browse a curated gallery where every featured sight is named and located.</p></Reveal>
        <div className="destination-grid">{destinations.map((destination, index) => <Reveal key={destination.name} className={`destination-card-wrap ${index === 0 || index === 7 ? "destination-wide" : ""}`}><button className="destination-card" onClick={() => { setSelected(destination); setActiveImage(0); }}><img src={destination.images[0].src} alt={`${destination.images[0].name}, ${destination.images[0].place}`} loading={index > 1 ? "lazy" : "eager"} /><span className="destination-overlay" /><span className="destination-copy"><small>{destination.eyebrow}</small><strong>{destination.name}</strong><span>{destination.description}</span></span><span className="destination-count">{destination.images.length} featured sights</span><span className="destination-open"><Camera size={17} /> Explore sights</span></button></Reveal>)}</div>
        <aside className="permit-note" role="note" aria-label="Sikkim travel permit advisory">
          <ShieldCheck aria-hidden="true" />
          <strong>Restricted Sikkim destinations are subject to permits, weather, road conditions and local regulations.</strong>
        </aside>
      </section>

      <Dialog open={Boolean(selected)} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="destination-dialog" showCloseButton>
          {selected && <>
            <div className="dialog-gallery">
              <div className="dialog-image-wrap">
                <img key={selected.images[activeImage].src} src={selected.images[activeImage].src} alt={`${selected.images[activeImage].name}, ${selected.images[activeImage].place}, ${selected.images[activeImage].region}`} />
                <span />
                <div className="image-caption"><small>{String(activeImage + 1).padStart(2, "0")} / {String(selected.images.length).padStart(2, "0")}</small><strong>{selected.images[activeImage].name}</strong><span><MapPin size={12} /> {selected.images[activeImage].place} · {selected.images[activeImage].region}</span></div>
                <button className="gallery-arrow gallery-prev" onClick={() => setActiveImage((activeImage - 1 + selected.images.length) % selected.images.length)} aria-label="Previous photo"><ChevronLeft /></button>
                <button className="gallery-arrow gallery-next" onClick={() => setActiveImage((activeImage + 1) % selected.images.length)} aria-label="Next photo"><ChevronRight /></button>
              </div>
              <div className="gallery-thumbnails" aria-label={`${selected.name} photo gallery`}>
                {selected.images.map((image, index) => <button key={`${image.name}-${image.src}`} className={index === activeImage ? "active" : ""} onClick={() => setActiveImage(index)} aria-label={`View ${image.name} in ${image.place}`}><img src={image.src} alt="" loading="lazy" /><span>{image.name}</span></button>)}
              </div>
            </div>
            <div className="dialog-copy"><p className="kicker">{selected.eyebrow}</p><DialogTitle>{selected.name}</DialogTitle><DialogDescription>{selected.description}</DialogDescription><p className="dialog-sights">{selected.sights}</p><div className="attraction-index"><span>Featured sightseeing places</span>{selected.images.map((image, index) => <button key={image.name} className={index === activeImage ? "active" : ""} onClick={() => setActiveImage(index)}><b>{String(index + 1).padStart(2, "0")}</b><span><strong>{image.name}</strong><small>{image.place} · {image.region}</small></span></button>)}</div><p className="gallery-hint"><Camera size={15} /> {selected.images.length} named, curated views</p><a className="button button-gold" href={whatsapp} target="_blank" rel="noreferrer">Plan this journey <ArrowRight size={16} /></a></div>
          </>}
        </DialogContent>
      </Dialog>

      <section className="section why-section">
        <Reveal className="why-visual"><img src="/gallery/g-22.webp" alt="Scenic Tsomgo Lake in East Sikkim" loading="lazy" /><div className="experience-seal"><span>Nearly</span><strong>10</strong><span>years</span></div></Reveal>
        <Reveal className="why-copy"><p className="kicker">Why travel with us</p><h2>Local knowledge.<br /><em>Personal attention.</em></h2><p>We combine practical route knowledge with friendly, straightforward assistance.</p><ul><li><ShieldCheck size={20} /><span><strong>Experienced guidance</strong> for local and outstation journeys</span></li><li><Headphones size={20} /><span><strong>Clear assistance</strong> before you confirm your booking</span></li><li><CarFront size={20} /><span><strong>Multiple vehicle options</strong> based on availability and group size</span></li><li><Route size={20} /><span><strong>Popular and offbeat routes</strong> across North Bengal and Sikkim</span></li></ul></Reveal>
      </section>

      <section className="section founder-section"><Reveal className="founder-card"><figure className="founder-photo"><img src="/founder-ranjan-sahani.webp" alt="Mr. Ranjan Sahani, founder of Royal Tours & Travels" loading="lazy" /><figcaption>Founder & travel professional</figcaption></figure><div className="founder-copy"><p className="kicker">Founder’s note</p><h2>Mr. Ranjan Sahani</h2><p>Royal Tours & Travels was founded by Mr. Ranjan Sahani, an experienced travel professional who has been successfully managing the business for approximately 10 years. His focus remains friendly communication, practical route planning and suitable travel options for every kind of traveller.</p></div><blockquote>“Your journey should feel comfortable from the very first conversation.”</blockquote></Reveal></section>

      <section className="section booking-section"><Reveal className="section-heading"><div><p className="kicker">Simple booking</p><h2>From enquiry to journey in <em>four easy steps.</em></h2></div></Reveal><div className="booking-grid">{[["01", "Contact us", "Call or WhatsApp us with your travel idea."], ["02", "Share details", "Send your dates, pickup point and group size."], ["03", "Choose an option", "Review suitable available travel choices."], ["04", "Confirm & travel", "Confirm your journey and get ready to explore."]].map(([number, title, text]) => <Reveal className="booking-step" key={number}><span>{number}</span><h3>{title}</h3><p>{text}</p></Reveal>)}</div></section>

      <section id="faqs" className="section faq-section"><Reveal className="faq-intro"><p className="kicker">Good to know</p><h2>Frequently asked <em>questions.</em></h2><p>Quick, clear answers for planning your trip from Siliguri.</p></Reveal><Reveal className="faq-list"><Accordion type="single" collapsible>{faqs.map((item, index) => <AccordionItem value={`faq-${index}`} key={item.q}><AccordionTrigger>{item.q}</AccordionTrigger><AccordionContent><PhoneLinkedText text={item.a} /></AccordionContent></AccordionItem>)}</Accordion></Reveal></section>

      <section id="contact" className="contact-section"><div className="contact-bg" aria-hidden="true" /><div className="contact-scrim" aria-hidden="true" /><Reveal className="contact-content"><p className="kicker">Start your next journey</p><h2>Beautiful destinations are <em>waiting for you.</em></h2><p>Tell us where you want to go. We’ll help with your cab, sightseeing and ticket booking requirements.</p><div className="contact-actions"><a className="button button-gold" href={whatsapp} target="_blank" rel="noreferrer"><MessageCircle size={18} /> Chat on WhatsApp</a><a className="button button-ghost" href="tel:+919749230783">Call +91 97492 30783</a></div></Reveal></section>

      <footer><div className="footer-grid"><div className="footer-brand"><img src="/royal-logo.png" alt="Royal Tours & Travels" /><p>Your trusted travel agency, cab service and ticket booking centre in Siliguri.</p><div className="social-row" aria-label="Royal Tours & Travels online links"><a href="https://www.google.com/maps/search/?api=1&query=Royal+Tours+%26+Travels+Darjeeling+More+Mallaguri+Siliguri" target="_blank" rel="noopener noreferrer" title="Find Royal Tours & Travels on Google Maps" aria-label="Google Maps"><MapPin size={18} /></a><a href="https://www.facebook.com/search/top?q=Royal%20Tours%20%26%20Travels%20Siliguri" target="_blank" rel="noopener noreferrer" title="Search Royal Tours & Travels on Facebook" aria-label="Facebook search"><Globe2 size={18} /></a><a href="https://www.instagram.com/explore/search/keyword/?q=Royal%20Tours%20%26%20Travels%20Siliguri" target="_blank" rel="noopener noreferrer" title="Search Royal Tours & Travels on Instagram" aria-label="Instagram search"><AtSign size={18} /></a></div></div><div><h3>Quick links</h3><a href="#home">Home</a><a href="#about">About us</a><a href="#services">Services</a><a href="#destinations">Destinations</a><a href="#faqs">FAQs</a><a href="#contact">Contact</a></div><div><h3>Services</h3><a href={whatsapp} target="_blank" rel="noreferrer">Private cab</a><a href={whatsapp} target="_blank" rel="noreferrer">Sumo & Traveller</a><a href="#destinations">Sightseeing</a><a href={whatsapp} target="_blank" rel="noreferrer">Bus & air tickets</a></div><div className="footer-contact"><h3>Contact</h3><a href="tel:+919749230783">+91 97492 30783</a><a className="footer-address" href="https://www.google.com/maps/search/?api=1&query=Hotel+Tower+Bangla+Darjeeling+More+Mallaguri+Siliguri+734003" target="_blank" rel="noopener noreferrer">In front of Hotel Tower Bangla,<br />Darjeeling More, Mallaguri,<br />Siliguri – 734003, West Bengal</a></div></div><div className="copyright"><span>© 2026 Royal Tours & Travels. All Rights Reserved.</span><span>Developed & crafted by <a href="https://redpumpkin.in/" target="_blank" rel="noopener noreferrer">Red Pumpkin Marketing</a>.</span></div></footer>

      <a className="whatsapp-float" href={whatsapp} target="_blank" rel="noreferrer" aria-label="Chat with Royal Tours and Travels on WhatsApp"><MessageCircle size={24} /><span>WhatsApp us</span></a>
    </main>
  );
}
