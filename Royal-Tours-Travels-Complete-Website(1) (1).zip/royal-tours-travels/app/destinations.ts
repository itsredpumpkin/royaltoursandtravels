export type Attraction = {
  name: string;
  place: string;
  region: string;
  src: string;
};

export type Destination = {
  name: string;
  eyebrow: string;
  description: string;
  sights: string;
  images: Attraction[];
};

const destinationData: Destination[] = [
  {
    name: "Darjeeling",
    eyebrow: "Queen of the Hills",
    description: "Toy-train heritage, tea gardens, sunrise viewpoints and celebrated Himalayan landmarks in and around Darjeeling town.",
    sights: "Tiger Hill · Batasia Loop · Ghoom · Happy Valley · Chowrasta",
    images: [
      { name: "Tiger Hill Sunrise", place: "Tiger Hill, Ghoom", region: "Darjeeling District, West Bengal", src: "https://wanderon-images.gumlet.io/gallery/new/2026/05/01/1777626033961-sunrise-view-in-darjeeling.png?auto=compress%2Cformat&w=1920" },
      { name: "Batasia Loop", place: "Ghoom", region: "Darjeeling District, West Bengal", src: "https://www.darjeelingriders.com/blog/wp-content/uploads/2019/07/Batasia-loop-Darjeeling-1360x765.jpg" },
      { name: "Japanese Peace Pagoda", place: "Jalapahar, Darjeeling", region: "Darjeeling District, West Bengal", src: "https://img.avianexperiences.com/attractions/e47a8464-ac9c-41da-b53c-cf63e7328ce6/Japanes_Peace_Pagoda5.jpg" },
      { name: "Rock Garden", place: "Chunnu Summer Falls, Darjeeling", region: "Darjeeling District, West Bengal", src: "https://3.bp.blogspot.com/-cv1Q-1qhPHo/WbEWsQ89_xI/AAAAAAAABrY/tj6U0TInP8Y8fnvKgztoa1TbYS4TqNq5gCLcBGAs/s1600/5-Rock-Garden-Darjeeling.jpg" },
      { name: "Happy Valley Tea Estate", place: "Lebong Cart Road, Darjeeling", region: "Darjeeling District, West Bengal", src: "https://www.aaradhyatourism.com/images/destinations/tea-estate.jpg" },
      { name: "Himalayan Mountaineering Institute", place: "Jawahar Parbat, Darjeeling", region: "Darjeeling District, West Bengal", src: "https://www.tourism-of-india.com/blog/wp-content/uploads/2021/04/Himalayan-Mountaineering-Institute.jpg" },
      { name: "Yiga Choeling (Ghoom) Monastery", place: "Ghoom", region: "Darjeeling District, West Bengal", src: "https://www.viyankatravels.com/images/sightseeing/18451ghoom-monastery-sightseeing.jpg" },
      { name: "Chowrasta & Mall Road", place: "Darjeeling Town", region: "Darjeeling District, West Bengal", src: "https://pbs.twimg.com/media/E8jQnprUYAQX1mt?format=jpg&name=large" },
    ],
  },
  {
    name: "Gangtok",
    eyebrow: "The Sikkim Capital",
    description: "A lively mountain capital with pedestrian streets, monasteries, waterfalls and panoramic viewpoints.",
    sights: "MG Marg · Rumtek · Tashi View Point · Ganesh Tok · Hanuman Tok",
    images: [
      { name: "MG Marg", place: "Gangtok City Centre", region: "Gangtok District, Sikkim", src: "https://cf-img-a-in.tosshub.com/sites/visualstory/wp/2024/06/cropped-MG-marg-thumnail.jpg?size=1200%3A1600" },
      { name: "Rumtek Monastery", place: "Rumtek", region: "Gangtok District, Sikkim", src: "https://www.shrineyatra.com/wp-content/uploads/2022/03/Best-Monastery-in-Sikkim-1.jpg" },
      { name: "Tashi View Point", place: "Tashi, Gangtok", region: "Gangtok District, Sikkim", src: "https://cdn1.tripoto.com/media/filter/nxxl/img/100758/TripDocument/1521198828_img_9179_1.jpg.webp" },
      { name: "Ganesh Tok", place: "Upper Sichey, Gangtok", region: "Gangtok District, Sikkim", src: "https://res.cloudinary.com/kmadmin/image/upload/v1618466940/kiomoi/Gangtok_Ganesh_Tok_1618466939245.jpg" },
      { name: "Hanuman Tok", place: "Gangtok", region: "Gangtok District, Sikkim", src: "https://avathioutdoors.gumlet.io/travelGuide/dev/gangtok_P1721.jpg?compress=true&format=webp&h=630&q=80&w=1200" },
      { name: "Banjhakri Falls", place: "Ranka Road, Gangtok", region: "Gangtok District, Sikkim", src: "https://media1.thrillophilia.com/filestore/s3qn155qg6uuqqiylem58yq9x1l2_shutterstock_2321755807.jpg" },
    ],
  },
  {
    name: "North Sikkim",
    eyebrow: "High Himalayan Wonder",
    description: "High-altitude lakes, flower valleys, remote villages and waterfalls on some of Sikkim’s most dramatic roads.",
    sights: "Lachung · Lachen · Yumthang · Gurudongmar · Zero Point",
    images: [
      { name: "Gurudongmar Lake", place: "Near Thangu", region: "Mangan District, North Sikkim", src: "https://media.cntraveler.com/photos/648b535ffc96ce0cb0026ff4/4:3/w_2656,h_1992,c_limit/Alpine%20lakes%20(update)_Gurudongmar%20Lake%20(India)_nupur-sharma-ne2LanLdjd8-unsplash.jpg" },
      { name: "Yumthang Valley", place: "Near Lachung", region: "Mangan District, North Sikkim", src: "https://cdn.sanity.io/images/k7aa4gdi/production/fb46e9144d3112f298e435dd4a0f786634273983-1500x1002.jpg" },
      { name: "Zero Point (Yumesamdong)", place: "Beyond Yumthang", region: "Mangan District, North Sikkim", src: "https://thewanderyak.com/public/images/thumbnails/img_695e15ea103c7.webp" },
      { name: "Lachen Village", place: "Lachen", region: "Mangan District, North Sikkim", src: "https://wanderon-images.gumlet.io/blogs/new/2024/08/lachen.jpg?auto=compress,format&w=1920" },
      { name: "Lachung Village", place: "Lachung", region: "Mangan District, North Sikkim", src: "https://www.tourmyindia.com/blog/wp-content/uploads/2021/10/Yumthang-Valley-Sikkim.jpg" },
      { name: "Thangu Valley", place: "Thangu", region: "Mangan District, North Sikkim", src: "https://northbengaltourism.com/images/offbeat/thangu_valley_1.webp" },
      { name: "Seven Sisters Waterfall", place: "Gangtok–Lachung Road", region: "Mangan District, North Sikkim", src: "https://media1.thrillophilia.com/filestore/s3qn155qg6uuqqiylem58yq9x1l2_shutterstock_2321755807.jpg" },
      { name: "Bhim Nala Waterfall", place: "Near Lachung", region: "Mangan District, North Sikkim", src: "https://static2.tripoto.com/media/filter/tst/img/1643111/SpotDocument/1683221657_1683221653442.jpg.webp" },
    ],
  },
  {
    name: "East Sikkim",
    eyebrow: "Lakes & Old Silk Route",
    description: "Alpine lakes, historic mountain passes and the celebrated hairpin bends of the Old Silk Route.",
    sights: "Tsomgo · Nathula · Baba Mandir · Zuluk · Aritar",
    images: [
      { name: "Tsomgo (Changu) Lake", place: "Jawaharlal Nehru Road", region: "Gangtok District, East Sikkim", src: "https://i.pinimg.com/originals/48/13/56/48135612f92b3a765047a0dcf20a16ad.jpg" },
      { name: "Nathula Pass", place: "India–China Border", region: "Gangtok District, East Sikkim", src: "https://media1.thrillophilia.com/filestore/0zgpyxr3cbcoq3r3bza0t4oz5pcv_nathula-pass-in-sikkim.webp" },
      { name: "Baba Harbhajan Singh Mandir", place: "Kupup–Nathula Road", region: "Gangtok District, East Sikkim", src: "https://staticimg.amarujala.com/assets/images/2020/02/29/baba-harbhajan-singh-mandir_1582952425.jpeg?dpr=2.6&q=90&w=1600" },
      { name: "Zuluk Zigzag Road", place: "Zuluk", region: "Pakyong District, East Sikkim", src: "https://hillstarholidays.com/wp-content/uploads/2022/09/Zig-Zag_Road_Silk_Route_Sikkim_India-scaled.jpg" },
      { name: "Kupup Lake (Elephant Lake)", place: "Kupup", region: "Gangtok District, East Sikkim", src: "https://d3sftlgbtusmnv.cloudfront.net/blog/wp-content/uploads/2024/08/Kupup-lake.jpeg" },
      { name: "Thambi View Point", place: "Old Silk Route, Zuluk", region: "Pakyong District, East Sikkim", src: "https://d3gw4aml0lneeh.cloudfront.net/assets/locations/17391/f1D5ZpmGhobd.jpg" },
      { name: "Lampokhari Lake", place: "Aritar", region: "Pakyong District, East Sikkim", src: "https://storage.googleapis.com/stateless-www-justwravel-com/2025/09/b72fcaf7-aritar-lake.jpg" },
      { name: "Nathang Valley", place: "Old Silk Route", region: "Gangtok District, East Sikkim", src: "https://res.cloudinary.com/kmadmin/image/upload/v1756472987/kiomoi/Nathang_Valley_4537.jpg" },
    ],
  },
  {
    name: "South Sikkim",
    eyebrow: "Spiritual & Scenic",
    description: "Monumental sacred sites, tea country, monasteries and green Himalayan viewpoints around Namchi and Ravangla.",
    sights: "Namchi · Ravangla · Buddha Park · Temi · Tarey Bhir",
    images: [
      { name: "Buddha Park", place: "Ravangla", region: "Namchi District, South Sikkim", src: "https://media.assettype.com/outlooktraveller/2023-11/8a6b2722-c6b8-46a2-965b-c6206c724d97/shutterstock_2155894593__1_.jpg" },
      { name: "Siddheshwar Dham (Char Dham)", place: "Solophok, Namchi", region: "Namchi District, South Sikkim", src: "https://helpthetourists.in/destination/img/south-sikkim/namchi/namchi-3.webp" },
      { name: "Temi Tea Garden", place: "Temi", region: "Namchi District, South Sikkim", src: "https://assets.cntraveller.in/photos/676e7ca2e29b3f5c3332e97a/master/w_1600,c_limit/Temi%20Tea%20Garden%20pc%20Sultan%20Akhtar,%20Dreamstime.jpg" },
      { name: "Samdruptse Hill", place: "Namchi", region: "Namchi District, South Sikkim", src: "https://upload.wikimedia.org/wikipedia/commons/5/55/Panoramic_view_of_large_statue_of_Guru_Padmasambhava_%28Guru_Rinpoche%29m_Namchi.jpg" },
      { name: "Sai Temple", place: "Assangthang, Namchi", region: "Namchi District, South Sikkim", src: "https://upload.wikimedia.org/wikipedia/commons/9/9d/Sai_Temple_in_Namchi%2C_Sikkim.jpg" },
      { name: "Ngadak Monastery", place: "Namchi", region: "Namchi District, South Sikkim", src: "https://wanderon-images.gumlet.io/blogs/new/2024/07/ngadak-monastery.jpg?auto=compress,format&w=1920" },
      { name: "Tarey Bhir", place: "Sadam", region: "Namchi District, South Sikkim", src: "https://www.setmytrip.in/wp-content/uploads/2024/08/PSX_20240811_102512.jpg" },
      { name: "Maenam Hill", place: "Above Ravangla", region: "Namchi District, South Sikkim", src: "https://media.assettype.com/outlooktraveller%2F2024-01%2F81e1b24d-51e4-48bc-ae06-39e4b0d1df1a%2Fravangla1.jpg" },
    ],
  },
  {
    name: "West Sikkim",
    eyebrow: "Sacred Lakes & Peaks",
    description: "Ancient capitals, monasteries, sacred lakes and Kanchenjunga viewpoints across the Pelling and Yuksom circuit.",
    sights: "Pelling · Yuksom · Khecheopalri · Pemayangtse · Rabdentse",
    images: [
      { name: "Pelling Skywalk & Chenrezig Statue", place: "Pelling", region: "Gyalshing District, West Sikkim", src: "https://images.beyondyatra.com/dest/rumtek-monastery/places/pelling-skywalk-sikkim-india_img_10.jpg" },
      { name: "Khecheopalri Lake", place: "Khecheopalri", region: "Gyalshing District, West Sikkim", src: "https://www.setmytrip.in/wp-content/uploads/2024/09/Khecheopalri-Lake-Pelling-Sightseeing.jpg" },
      { name: "Pemayangtse Monastery", place: "Pemayangtse, Pelling", region: "Gyalshing District, West Sikkim", src: "https://upload.wikimedia.org/wikipedia/commons/7/7a/Pemayangtse_Monastery%2C_Pelling%2C_West_Sikkim_01.jpg" },
      { name: "Rabdentse Ruins", place: "Near Pelling", region: "Gyalshing District, West Sikkim", src: "https://assets.cntraveller.in/photos/61f37fee2a4c3abc8e111dba/16:9/w_1920,h_1080,c_limit/Rabdentse%20Ruins%20lead.jpg" },
      { name: "Kanchenjunga Falls", place: "Pelling–Yuksom Road", region: "Gyalshing District, West Sikkim", src: "https://res.cloudinary.com/kmadmin/image/upload/v1618571062/kiomoi/Pelling_Kanchenjunga_Falls_1618571060925.jpg" },
      { name: "Yuksom", place: "Yuksom", region: "Gyalshing District, West Sikkim", src: "https://www.easeindiatrip.com/images/sikkim-img/yuksom-attr.jpg" },
      { name: "Tashiding Monastery", place: "Tashiding", region: "Gyalshing District, West Sikkim", src: "https://www.savaari.com/blog/wp-content/uploads/2024/10/Tashiding-Monastery.webp" },
      { name: "Singshore Bridge", place: "Dentam", region: "Gyalshing District, West Sikkim", src: "https://www.incredibleindia.gov.in/content/dam/incredible-india/images/trips/sikkim/7-day-trip-from-monasteries-to-mountains-a-week-in-sikkim/singshore-suspension-bridge-sikkim-tri-iter-day3.jpg" },
    ],
  },
  {
    name: "Kalimpong",
    eyebrow: "Quiet Hill Escape",
    description: "Flower nurseries, monasteries and open views over the Teesta valley and distant Himalayan peaks.",
    sights: "Deolo Hill · Durpin Dara · Zang Dhok Palri · Cactus Nursery",
    images: [
      { name: "Deolo Hill", place: "Deolo, Kalimpong", region: "Kalimpong District, West Bengal", src: "https://media.assettype.com/outlooktraveller/2024-01/13844b47-3fde-42ba-bb00-b7d79ac23757/Kalimpong_Deolo_Hill.jpg?auto=format,compress&fit=max&w=1920" },
      { name: "Durpin Dara View Point", place: "Durpin Hill, Kalimpong", region: "Kalimpong District, West Bengal", src: "https://cdn.guidetour.in/wp-content/uploads/2018/01/Durpin-Dara.jpg.webp" },
      { name: "Zang Dhok Palri Phodang", place: "Durpin Hill, Kalimpong", region: "Kalimpong District, West Bengal", src: "https://tripxl.com/blog/wp-content/uploads/2024/12/Zang-Dhok-Palri-Phodang-Monastery-1.jpg" },
      { name: "Pine View Nursery", place: "Atisha Road, Kalimpong", region: "Kalimpong District, West Bengal", src: "https://assets.simplotel.com/simplotel/image/upload/x_0,y_205,w_1024,h_577,r_0,c_crop/q_80,w_1600,c_limit/summit-hotels-resorts/cactus-nursery" },
      { name: "Morgan House", place: "Chandraloke, Kalimpong", region: "Kalimpong District, West Bengal", src: "https://upload.wikimedia.org/wikipedia/commons/c/cb/Morgan_House_Kalimpong_2.jpg" },
      { name: "Teesta Valley View", place: "Kalimpong", region: "Kalimpong District, West Bengal", src: "https://nbstc.in/tourism/file_store/products/big/1270851341686227616s6.jpg" },
    ],
  },
  {
    name: "Mirik",
    eyebrow: "Lakeside Serenity",
    description: "A relaxed hill circuit with a lake, pine forest, tea gardens and sweeping border viewpoints.",
    sights: "Sumendu Lake · Bokar Monastery · Pashupati Market · Tea Gardens",
    images: [
      { name: "Sumendu Lake", place: "Mirik Town", region: "Darjeeling District, West Bengal", src: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Mirik_Lake_a.k.a_Sumendu_Lake.jpg/1920px-Mirik_Lake_a.k.a_Sumendu_Lake.jpg" },
      { name: "Indreni Bridge", place: "Sumendu Lake, Mirik", region: "Darjeeling District, West Bengal", src: "https://www.beyondyatra.com/assets/images/imgtg/bagdogra/nr/mirik_bagdogra_west_bengal_india.jpg" },
      { name: "Bokar Monastery", place: "Mirik", region: "Darjeeling District, West Bengal", src: "https://d3gw4aml0lneeh.cloudfront.net/assets/locations/ahO7CPUhiyHF.jpg" },
      { name: "Mirik Tea Gardens", place: "Mirik–Soureni Road", region: "Darjeeling District, West Bengal", src: "https://oddessemania.in/wp-content/uploads/2025/05/Happy-Valley-Tea-estate-Oddessemania.jpg" },
      { name: "Pine Forest", place: "Mirik", region: "Darjeeling District, West Bengal", src: "https://d34vm3j4h7f97z.cloudfront.net/optimized/4X/4/7/2/472250f0eb1e22f1ec9a16ec04a6570da1df9f28_2_1380x920.jpeg" },
      { name: "Pashupati Market Excursion", place: "Indo–Nepal Border near Mirik", region: "Darjeeling District circuit", src: "https://www.sociogenie.com/wp-content/uploads/2016/12/Mirik-west-bengal.jpg" },
    ],
  },
  {
    name: "Kurseong",
    eyebrow: "Land of White Orchids",
    description: "Tea estates, forest roads, heritage rail and peaceful viewpoints in the lower Darjeeling hills.",
    sights: "Eagle’s Crag · Dow Hill · Makaibari · Giddapahar · Toy Train",
    images: [
      { name: "Eagle’s Crag View Point", place: "Kurseong Town", region: "Darjeeling District, West Bengal", src: "https://dhfsgw5w7ztx1.cloudfront.net/public/destinations/kurseong/kurseong-eagles-crag-1.jpg" },
      { name: "Dow Hill Forest", place: "Dow Hill, Kurseong", region: "Darjeeling District, West Bengal", src: "https://commons.wikimedia.org/wiki/Special:Redirect/file/Dow_hill_Kurseong.jpg?width=1920" },
      { name: "Makaibari Tea Estate", place: "Makaibari, Kurseong", region: "Darjeeling District, West Bengal", src: "https://cdn.shopify.com/s/files/1/0291/9381/files/Tea-Estate-9.jpg?v=1664263331" },
      { name: "Giddapahar View Point", place: "Giddapahar, Kurseong", region: "Darjeeling District, West Bengal", src: "https://images.beyondyatra.com/dest/mirik/places/giddapahar-view-point-west-bengal-india_img_1.jpg" },
      { name: "Darjeeling Himalayan Railway", place: "Kurseong Station", region: "Darjeeling District, West Bengal", src: "https://photos.wikimapia.org/p/00/01/66/93/61_big.jpg" },
      { name: "Netaji Subhas Chandra Bose Museum", place: "Giddapahar, Kurseong", region: "Darjeeling District, West Bengal", src: "https://hblimg.mmtcdn.com/content/hubble/img/kuersong/mmt/activities/t_trp/m_Netaji%20Subhash%20Chandra%20Bose%20Museum_3_l_415_553.jpg?im=Resize%3D%281200%2C570%29" },
      { name: "Ambotia Shiva Temple", place: "Ambotia Tea Estate, Kurseong", region: "Darjeeling District, West Bengal", src: "https://tripxl.com/blog/wp-content/uploads/2024/11/Ambootia-Shiva-Temple.jpg" },
      { name: "St. Mary’s Hill", place: "Kurseong", region: "Darjeeling District, West Bengal", src: "https://images.ixigo.com/node_image/f_auto,w_1600/imageURL?url=https%3A%2F%2Fta.ixigo.es%2Fv3%2Fimages-itinerary%2Fkurseong-tea-garden-trails%402x.jpg" },
    ],
  },
  {
    name: "Offbeat Stays & Camping",
    eyebrow: "Beyond the Usual",
    description: "Village homestays, forest escapes and nature camps for slow travel, quiet mornings and memorable nights outdoors.",
    sights: "Sittong · Tinchuley · Chatakpur · Lepchajagat · Lamahatta · Chakung",
    images: [
      { name: "Tinchuley Village Stay", place: "Tinchuley", region: "Darjeeling District, West Bengal", src: "https://www.darjeelingtourism.co/assets/images/homepage-1/2.tinchuley-village.jpg" },
      { name: "Sittong Orange Village Stay", place: "Sittong", region: "Darjeeling District, West Bengal", src: "https://gos3.ibcdn.com/aa340bb2-9ddc-4b70-9d5a-19b2bf893578.jpeg" },
      { name: "Chatakpur Eco Village", place: "Senchal Wildlife Sanctuary", region: "Darjeeling District, West Bengal", src: "https://northbengaltourism.com/images/holiday/828x466_chatakpur.jpg" },
      { name: "Lepchajagat Forest Stay", place: "Lepchajagat", region: "Darjeeling District, West Bengal", src: "https://northbengaltourism.com/images/offbeat/lepchajagat_1.webp" },
      { name: "Lamahatta Eco Park Stay", place: "Lamahatta", region: "Darjeeling District, West Bengal", src: "https://dynamic-media-cdn.tripadvisor.com/media/photo-o/17/eb/29/7f/lamahatta.jpg?h=1200&s=1&w=1800" },
      { name: "Takdah Heritage Stay", place: "Takdah Cantonment", region: "Darjeeling District, West Bengal", src: "https://images.fusionstays.com/files/cache/6ea/6eaeb661379545f22701eb11fd73af57ba439abfc1d49b50a78e43546dda2210.webp" },
      { name: "Chakung Mountain Camp", place: "Chakung", region: "Gyalshing District, West Sikkim", src: "https://offbeatsikkim.com/_next/image?q=90&url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2F1kau33ay%2Fproduction%2F8dda79419cc081ad2ed1e3d343402a73384e6ecb-3024x4032.jpg&w=1920" },
      { name: "Lepchakha Jungle Camp", place: "Buxa–Lepchakha", region: "Alipurduar District, Dooars", src: "https://lepchakhahomestay.com/storage/2024/09/lepchakha-jungle-camp-jalpaiguri-home-stay-0jty8bx54o.jpg" },
    ],
  },
];

let galleryImageNumber = 0;

export const destinations: Destination[] = destinationData.map((destination) => ({
  ...destination,
  images: destination.images.map((image) => ({
    ...image,
    src: `/gallery/g-${String(galleryImageNumber++).padStart(2, "0")}.webp`,
  })),
}));
